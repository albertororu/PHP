<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplicacion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <ul>
        <li><a href="usuario.php">Crear usuario </a></li>
        <li><a href="modificar.php">Modificar datos </a></li>
        <li><a href="eliminar.php">Eliminar un usuario </a></li>
        <li><a href="logout.php">Cerrar sesion</a></li>
        </ul>
    </nav>
    <h3>Bienvenido, has accedido correctamente a la página.</h3>
    <h5>Página creada por Alberto Romero Rubiales</h5>
</body>
</html>